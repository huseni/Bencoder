package com.huseni.bencode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;


public class DecodeBencodes {
	Integer strPtr = 0;
	String decodeSubStr;
	public static void main(String[] args) {

		// test string
		System.out.println(new DecodeBencodes().decode("10:testString"));
		// test integer
		System.out.println(new DecodeBencodes().decode("i2020e"));
		// list has maps
		System.out.println(new DecodeBencodes().decode("li555el12:Buenos Airesi100eei7ed14:type of animali123e3:xyzi88eee"));
		// integer keys and values has lists
		System.out.println(new DecodeBencodes().decode("di555el12:Buenos Airesi100eei7e14:type of animali123el3:xyzi44eee"));
		// Invalid case 
		System.out.println(new DecodeBencodes().decode("929"));

	}
	// Entry Function for Decode
	public Object decode(String strToDecode){
		if(strToDecode.startsWith("d")){
			return decodeMap(strToDecode);
		}else if(strToDecode.startsWith("l")){
			return decodeList(strToDecode);
		}else if(strToDecode.startsWith("i")){
			return decodeInt(strToDecode);
		}else if(strToDecode.contains(":")){
			return decodeStr(strToDecode);
		}else {
			return ("Invalid String");
		}
	}

	private String decodeStr(String str) {
		try {
			Integer colonPos = str.indexOf(':'); // to get the length of string
			Integer len;
			try {
				len = Integer.parseInt(str.substring(0, colonPos));
				strPtr = colonPos+len+1;
			} catch (NumberFormatException e) {
				System.out.println("NumberFormatException - Invalid String length : " + str);
				return null;
			}
			return str.substring(colonPos+1, strPtr);
		} catch (StringIndexOutOfBoundsException e) {
			System.out.println("StringIndexOutOfBoundsException - Invalid String: " + decodeSubStr );
		}catch (Exception e) {
			System.out.println("Exception - Invalid String: " + decodeSubStr );
		}
		return null;
	}

	private Integer decodeInt(String str) {
		Integer endofInt = str.indexOf('e');
		strPtr = endofInt;

		try {
			Integer intVal;
			intVal = Integer.parseInt(str.substring(1, strPtr++));
			return intVal;
		} catch (NumberFormatException e) {
			System.out.println("Invalid Number : " + str);
			return null;
		}

	}
	private List decodeList(String str) {
		List list = new ArrayList<>();
		try {
			decodeSubStr = str.substring(1, str.length());
			strPtr++;
			while( decodeSubStr.length() > 1 && !decodeSubStr.equals( "e") )
			{
				if(decodeSubStr.startsWith("e")){ // check end of list
					decodeSubStr=decodeSubStr.substring(strPtr, decodeSubStr.length());
					break;
				}else if(decodeSubStr.startsWith("d")){
					Map map = decodeMap(decodeSubStr);
					if (map == null)
						return null;
					list.add(map);
				}
				else if (decodeSubStr.startsWith("i")){
					Integer intVal = decodeInt(decodeSubStr);
					if (intVal == null)
						return null;
					list.add(intVal);
				}
				else if (decodeSubStr.startsWith("l")){ 
					List nList = decodeList(decodeSubStr);
					if (nList == null)
						return null;
					list.addAll(nList);
				}
				else if(decodeSubStr.contains(":")){ // check for byte 
					String nStr = decodeStr(decodeSubStr);
					if (nStr == null)
						return null;
					list.add(nStr);
				} 
				decodeSubStr = decodeSubStr.substring(strPtr,decodeSubStr.length());
				strPtr = 0; // reset pointer for new substringed string
			}
			strPtr++;
			return list;
		}catch (StringIndexOutOfBoundsException e) {
			System.out.println("StringIndexOutOfBoundsException - Invalid String: " + decodeSubStr );
		}catch (Exception e) {
			System.out.println("Exception - Invalid String: " + decodeSubStr );
		}
		return null;
	}

	private Map decodeMap(String str) {
		try {
			Map map = new TreeMap<>();
			decodeSubStr = str.substring(1, str.length());
			strPtr++;
		
			Object keyVal  = null;
			Object valueStr  = null;
			while( decodeSubStr.length() > 1 && !decodeSubStr.equals( "e") )
			{
				if(decodeSubStr.startsWith("e")){
					decodeSubStr=decodeSubStr.substring(strPtr, decodeSubStr.length());
					break;
				} else if(decodeSubStr.startsWith("d")){
					Map nMap = decodeMap(decodeSubStr);
					if (nMap == null)
						return null;
					if (keyVal == null ){
						keyVal = nMap;
					}else {
						valueStr = nMap;
					}	    
				}
				else if (decodeSubStr.startsWith("i")){
					Integer intVal = decodeInt(decodeSubStr);
					if (intVal == null)
						return null;
					if (keyVal == null ){
						keyVal = intVal;
					}else {
						valueStr = intVal;
					}	    		
				}
				else if (decodeSubStr.startsWith("l")){
					List nList = decodeList(decodeSubStr);
					if (nList == null)
						return null;
					if (keyVal == null ){
						keyVal = nList;
					}else {
						valueStr = nList;
					}	    	
				}
				else if(decodeSubStr.contains(":")){
					String nStr = decodeStr(decodeSubStr);
					if (nStr == null)
						return null;
					if (keyVal == null ){
						keyVal = nStr;
					}else {
						valueStr = nStr;
					}
				}
				if (keyVal != null  && valueStr != null ){
					map.put(keyVal, valueStr);
					keyVal = null;
					valueStr= null;
				}
				decodeSubStr = decodeSubStr.substring(strPtr,decodeSubStr.length());
				strPtr = 0; // reset the pointer for subsetted string
			}
			strPtr++;
			return map;
		} catch (StringIndexOutOfBoundsException e) {
			System.out.println("StringIndexOutOfBoundsException - Invalid String: " + decodeSubStr );
		}catch (Exception e) {
			System.out.println("Exception - Invalid String: " + decodeSubStr );
		}
		return null;
	}


}
