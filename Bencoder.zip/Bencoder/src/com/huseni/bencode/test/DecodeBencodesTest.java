package com.huseni.bencode.test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.List;

import org.hamcrest.core.IsInstanceOf;
import org.junit.Before;
import org.junit.Test;

import com.huseni.bencode.DecodeBencodes;


public class DecodeBencodesTest {

	DecodeBencodes decodeBencode;


	@Before
	public void setUp(){

		decodeBencode = new DecodeBencodes();
	}

	@Test
	public void testString(){
		System.out.println("Inside test String Decode");
		assertEquals(decodeBencode.decode("10:testString"),"testString");

	}
	@Test
	public void testInteger(){
		System.out.println("Inside test Integer Decode");
		assertEquals(decodeBencode.decode("i2020e"),2020);

	}
	@Test
	public void testList(){
		System.out.println("Inside test List Decode");
		assertEquals(decodeBencode.decode("li555el12:Buenos Airesi100eei7ed14:type of animali123e3:xyzi88eee").toString(),"[555, Buenos Aires, 100, 7, {type of animal=123, xyz=88}]");

	}
	@Test
	public void testDictionary(){
		System.out.println("Inside test Dictionary Decode");
		assertEquals(decodeBencode.decode("di555el12:Buenos Airesi100eei7e14:type of animali123el3:xyzi44eee").toString(),"{7=type of animal, 123=[xyz, 44], 555=[Buenos Aires, 100]}");

	}
	@Test
	public void testInvalidString(){
		System.out.println("Inside Invalidcase Decode");

		// Invalid case 
		assertEquals(decodeBencode.decode("929"),"Invalid String");

	}

}
