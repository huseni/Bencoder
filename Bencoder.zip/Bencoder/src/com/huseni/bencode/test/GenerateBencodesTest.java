package com.huseni.bencode.test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;

import com.huseni.bencode.GenerateBencodes;


public class GenerateBencodesTest {
	GenerateBencodes genBencode;	


	@Before
	public void setUp(){
		genBencode = new GenerateBencodes();
	}

	@Test
	public void testMap(){
		Map map = new TreeMap();
		map.put("dog", "type of animal");
		map.put("xyz",123);
		map.put("abc", "test");
		System.out.println("Inside testMap");
		assertEquals(genBencode.getBencode(map), "d3:abc4:test3:dog14:type of animal3:xyzi123ee");

	}
	@Test
	public void testArray(){
		System.out.println("Inside testArray");
		ArrayList places ;
		places = new ArrayList(
				Arrays.asList("Buenos Aires", 100));

		assertEquals(genBencode.getBencode(places) , "l12:Buenos Airesi100ee");

	}
	@Test
	public void testString(){
		System.out.println("Inside testString");
		assertEquals(genBencode.getBencode("testing") , "7:testing");

	}
	@Test
	public void testInteger(){
		System.out.println("Inside testInteger");
		assertEquals(genBencode.getBencode(34923) ,"i34923e");

	}
	@Test
	public void testNegInteger(){
		System.out.println("Inside testNegInteger");
		assertEquals(genBencode.getBencode(-1) , "i-1e");

	}
	@Test
	public void testSet(){
		System.out.println("Inside testSet");
		assertNull(genBencode.getBencode(new HashSet()));

	}




}
