package com.huseni.bencode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;


public class GenerateBencodes {

	public static void main(String[] args) {
		ArrayList places = new ArrayList(
				Arrays.asList("Buenos Aires", 100));
		Map map = new TreeMap();		
		map.put("dog", "type of animal");
		map.put("xyz",123);
		map.put("abc", "test");

		System.out.println(new GenerateBencodes().getBencode(map));
	}


	public String getBencode(Object obj){
		if (obj == null)
			return null;
		if (obj instanceof Integer)
			return getBencode((Integer)obj);
		else if (obj instanceof String)
			return getBencode((String)obj);
		else if (obj instanceof List)
			return getBencode((List)obj);
		else if (obj instanceof Map)
			return getBencode((Map)obj);
		return null;
	}


	String getBencode(Integer number){
		if (number == null )
			return null;
		return "i" + number + "e";
	}

	String getBencode(String str){
		if (str == null )
			return null;
		return str.length() + ":" + str;
	}

	String getBencode(List list){
		if (list == null)
			return null;
		StringBuffer bencodeStrBuffer = new StringBuffer();
		bencodeStrBuffer.append("l");

		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			Object obj = (Object) iterator.next();
			bencodeStrBuffer.append(new GenerateBencodes().getBencode(obj));

		}
		bencodeStrBuffer.append("e");
		return bencodeStrBuffer.toString();
	}
	String getBencode(Map map){
		if (map == null)
			return null;
		StringBuffer bencodeStrBuffer = new StringBuffer();
		bencodeStrBuffer.append("d");


		for (Iterator iterator = map.entrySet().iterator(); iterator.hasNext();) {
			Map.Entry pair = (Map.Entry)iterator.next();

			bencodeStrBuffer.append(new GenerateBencodes().getBencode(pair.getKey()));
			bencodeStrBuffer.append(new GenerateBencodes().getBencode(pair.getValue()));

		}
		bencodeStrBuffer.append("e");
		return bencodeStrBuffer.toString();
	}
}
